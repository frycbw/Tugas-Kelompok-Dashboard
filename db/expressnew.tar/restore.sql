--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Express";
--
-- Name: Express; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Express" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Indonesia.1252' LC_CTYPE = 'English_Indonesia.1252';


ALTER DATABASE "Express" OWNER TO postgres;

\connect "Express"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: penerimaan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.penerimaan() RETURNS integer
    LANGUAGE plpgsql
    AS $$
	DECLARE jumlah_penerimaan INTEGER;
	BEGIN
		jumlah_penerimaan	:= COUNT("id_transaksi") 
		FROM "tb_transaksi"  ;
	RETURN jumlah_penerimaan;
END$$;


ALTER FUNCTION public.penerimaan() OWNER TO postgres;

--
-- Name: pengiriman(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.pengiriman() RETURNS integer
    LANGUAGE plpgsql
    AS $$
	DECLARE jumlah_pengiriman INTEGER;
	BEGIN
		jumlah_pengiriman := COUNT("id_transaksi") 
		FROM "tb_transaksi" 
		WHERE "status" = 'Telah dikirim' ;
	RETURN jumlah_pengiriman;
END$$;


ALTER FUNCTION public.pengiriman() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tb_paket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_paket (
    id_paket bigint NOT NULL,
    jenis_paket character varying(255),
    deskripsi_paket character varying(255),
    jenis_pengiriman character varying(255),
    berat integer,
    jumlah integer
);


ALTER TABLE public.tb_paket OWNER TO postgres;

--
-- Name: tb_pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_pelanggan (
    id_pelanggan bigint NOT NULL,
    nama_pelanggan character varying(255),
    no_pelanggan bigint,
    kota_pelanggan character varying(64),
    "provinsi_pelanggan " character varying(255),
    kecamatan_pelanggan character varying(255),
    alamat_pelanggan character varying(255)
);


ALTER TABLE public.tb_pelanggan OWNER TO postgres;

--
-- Name: tb_penerima; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_penerima (
    id_penerima bigint NOT NULL,
    nama_penerima character varying(255),
    no_penerima character varying(255),
    kota_penerima character varying(255),
    provinsi_penerima character varying(255),
    kecamatan_penerima character varying(255),
    alamat_penerima character varying(255)
);


ALTER TABLE public.tb_penerima OWNER TO postgres;

--
-- Name: tb_transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_transaksi (
    id_transaksi bigint,
    id_paket bigint,
    id_pelanggan bigint,
    id_penerima bigint,
    tanggal date,
    status character varying(255),
    rating integer,
    harga money
);


ALTER TABLE public.tb_transaksi OWNER TO postgres;

--
-- Data for Name: tb_paket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_paket (id_paket, jenis_paket, deskripsi_paket, jenis_pengiriman, berat, jumlah) FROM stdin;
\.
COPY public.tb_paket (id_paket, jenis_paket, deskripsi_paket, jenis_pengiriman, berat, jumlah) FROM '$$PATH$$/2839.dat';

--
-- Data for Name: tb_pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_pelanggan (id_pelanggan, nama_pelanggan, no_pelanggan, kota_pelanggan, "provinsi_pelanggan ", kecamatan_pelanggan, alamat_pelanggan) FROM stdin;
\.
COPY public.tb_pelanggan (id_pelanggan, nama_pelanggan, no_pelanggan, kota_pelanggan, "provinsi_pelanggan ", kecamatan_pelanggan, alamat_pelanggan) FROM '$$PATH$$/2837.dat';

--
-- Data for Name: tb_penerima; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_penerima (id_penerima, nama_penerima, no_penerima, kota_penerima, provinsi_penerima, kecamatan_penerima, alamat_penerima) FROM stdin;
\.
COPY public.tb_penerima (id_penerima, nama_penerima, no_penerima, kota_penerima, provinsi_penerima, kecamatan_penerima, alamat_penerima) FROM '$$PATH$$/2838.dat';

--
-- Data for Name: tb_transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_transaksi (id_transaksi, id_paket, id_pelanggan, id_penerima, tanggal, status, rating, harga) FROM stdin;
\.
COPY public.tb_transaksi (id_transaksi, id_paket, id_pelanggan, id_penerima, tanggal, status, rating, harga) FROM '$$PATH$$/2840.dat';

--
-- Name: tb_paket tb_paket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_paket
    ADD CONSTRAINT tb_paket_pkey PRIMARY KEY (id_paket);


--
-- Name: tb_pelanggan tb_pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_pelanggan
    ADD CONSTRAINT tb_pelanggan_pkey PRIMARY KEY (id_pelanggan);


--
-- Name: tb_penerima tb_penerima_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_penerima
    ADD CONSTRAINT tb_penerima_pkey PRIMARY KEY (id_penerima);


--
-- Name: tb_transaksi id paket; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_transaksi
    ADD CONSTRAINT "id paket" FOREIGN KEY (id_paket) REFERENCES public.tb_paket(id_paket) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_transaksi id pelanggan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_transaksi
    ADD CONSTRAINT "id pelanggan" FOREIGN KEY (id_pelanggan) REFERENCES public.tb_pelanggan(id_pelanggan) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_transaksi id penerima; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_transaksi
    ADD CONSTRAINT "id penerima" FOREIGN KEY (id_penerima) REFERENCES public.tb_penerima(id_penerima) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

